#!/bin/bash
# ─────────────────────────────────────────────────────────────
# SetTraceFlag.sh
# Sets a debug trace flag for the current user in a Salesforce org
# Usage: ./SetTraceFlag.sh <org-alias> <hours>
# Example: ./SetTraceFlag.sh extremity-sandbox 24
# ─────────────────────────────────────────────────────────────

ORG_ALIAS="${1:-extremity-sandbox}"
HOURS="${2:-24}"

echo "🔧 Setting trace flag on org: $ORG_ALIAS for $HOURS hour(s)"

# Get current user ID
USER_ID=$(sf data query \
  --query "SELECT Id FROM User WHERE IsActive = true AND Profile.Name != 'Chatter Free User' LIMIT 1" \
  --target-org "$ORG_ALIAS" \
  --result-format json | python3 -c "
import json, sys
data = json.load(sys.stdin)
records = data.get('result', {}).get('records', [])
if records:
    print(records[0]['Id'])
else:
    print('')
")

if [ -z "$USER_ID" ]; then
  echo "❌ Could not retrieve user ID. Are you authenticated to $ORG_ALIAS?"
  exit 1
fi

echo "👤 Targeting User ID: $USER_ID"

# Calculate expiry date
EXPIRY=$(python3 -c "
from datetime import datetime, timedelta
expiry = datetime.utcnow() + timedelta(hours=$HOURS)
print(expiry.strftime('%Y-%m-%dT%H:%M:%S.000+0000'))
")

echo "⏱️  Expiry: $EXPIRY"

# Check if a DebugLevel named 'ApexAnalyzer' exists, create if not
DEBUG_LEVEL_ID=$(sf data query \
  --query "SELECT Id FROM DebugLevel WHERE DeveloperName = 'ApexAnalyzer'" \
  --target-org "$ORG_ALIAS" \
  --result-format json | python3 -c "
import json, sys
data = json.load(sys.stdin)
records = data.get('result', {}).get('records', [])
print(records[0]['Id'] if records else '')
")

if [ -z "$DEBUG_LEVEL_ID" ]; then
  echo "📋 Creating DebugLevel 'ApexAnalyzer'..."
  DEBUG_LEVEL_ID=$(sf data create record \
    --sobject DebugLevel \
    --values "DeveloperName=ApexAnalyzer MasterLabel='Apex Analyzer' ApexCode=FINEST ApexProfiling=INFO Database=INFO System=DEBUG Workflow=INFO Validation=INFO Callout=INFO" \
    --target-org "$ORG_ALIAS" \
    --result-format json | python3 -c "
import json, sys
data = json.load(sys.stdin)
print(data.get('result', {}).get('id', ''))
")
  echo "✅ DebugLevel created: $DEBUG_LEVEL_ID"
else
  echo "✅ Using existing DebugLevel: $DEBUG_LEVEL_ID"
fi

# Create the TraceFlag
echo "🚩 Creating TraceFlag..."
TRACE_FLAG_ID=$(sf data create record \
  --sobject TraceFlag \
  --values "TracedEntityId=$USER_ID LogType=USER_DEBUG DebugLevelId=$DEBUG_LEVEL_ID StartDate=$(date -u +%Y-%m-%dT%H:%M:%S.000+0000) ExpirationDate=$EXPIRY" \
  --target-org "$ORG_ALIAS" \
  --result-format json | python3 -c "
import json, sys
data = json.load(sys.stdin)
print(data.get('result', {}).get('id', ''))
")

if [ -n "$TRACE_FLAG_ID" ]; then
  echo ""
  echo "✅ TraceFlag created successfully!"
  echo "   ID:      $TRACE_FLAG_ID"
  echo "   Org:     $ORG_ALIAS"
  echo "   User:    $USER_ID"
  echo "   Expires: $EXPIRY"
  echo ""
  echo "Salesforce will now generate debug logs for this user."
  echo "Trigger some Apex (run tests, open pages, execute flows) then run the workflow."
else
  echo "❌ Failed to create TraceFlag. Check org permissions."
  exit 1
fi
