# 🚀 Setup Guide: AI Powered Apex Logs Analyzer
## Kicksaw · Extremity Sandbox

---

## Overview

This workflow connects to your **Extremity Sandbox**, pulls recent Apex debug logs via Salesforce CLI, and runs AI analysis locally on the GitHub Actions runner using **Ollama** (Mistral or CodeLlama). No log data leaves the runner — fully private.

Analysis covers:
- ⚡ Governor limit violations (SOQL, DML, CPU, heap, callouts)
- 🐢 Performance bottlenecks (N+1 SOQL, DML in loops)
- 💥 Apex errors & exceptions
- 🧹 Anti-patterns & code quality issues

---

## Step 1: Generate Your Salesforce Auth URL

On your local machine (with SF CLI installed and already authenticated to Extremity Sandbox):

```bash
# Authenticate if not already done
sf org login web --alias extremity-sandbox

# Generate the SFDX auth URL
sf org display --target-org extremity-sandbox --verbose --json | grep sfdxAuthUrl
```

This outputs something like:
```
force://PlatformCLI::5Aep861...longstring...@test.salesforce.com
```

Copy this entire string — you'll need it in Step 2.

> ⚠️ **Security**: This URL grants full org access. Treat it like a password. Never commit it to your repo.

---

## Step 2: Add the Secret to GitHub

1. Go to your Kicksaw GitHub repository
2. Navigate to **Settings → Secrets and variables → Actions**
3. Click **New repository secret**
4. Name: `EXTREMITY_SANDBOX_AUTH_URL`
5. Value: Paste the full `force://...` auth URL from Step 1
6. Click **Add secret**

---

## Step 3: Add the Workflow File

Place the workflow file in your repository:

```
your-repo/
└── .github/
    └── workflows/
        └── LogsAnalyzer.yml   ← copy the provided file here
```

Commit and push to your main/default branch.

---

## Step 4: Enable Trace Flags (Critical!)

> The workflow **analyses existing logs** — it does not create them. You must have trace flags active so Salesforce generates logs.

### Option A: Manual (Developer Console)
1. Open Salesforce Setup → **Debug Logs**
2. Click **New** under Monitored Users
3. Select your user (or the integration user)
4. Set expiry date and log levels:
   - Apex Code: **FINEST**
   - Apex Profiling: **INFO**
   - Database: **INFO**
   - System: **DEBUG**

### Option B: Use the Helper Script (see `SetTraceFlag.sh`)
```bash
chmod +x SetTraceFlag.sh
./SetTraceFlag.sh extremity-sandbox 24
```
This sets a 24-hour trace flag for your current user.

---

## Step 5: Run the Workflow

1. Go to your GitHub repo → **Actions** tab
2. Select **"AI Powered Apex Logs Analyzer"** from the left sidebar
3. Click **"Run workflow"**
4. Fill in the inputs:

| Input | Recommended Value | Notes |
|-------|-------------------|-------|
| `days_back` | `7` | How far back to fetch logs |
| `model_name` | `mistral` | Best balance of speed/quality |
| `log_level_filter` | `ALL` | Or `ERROR` for issues-only |
| `max_logs` | `20` | Keep ≤30 to avoid timeout |

5. Click **"Run workflow"** (green button)

---

## Step 6: Download Your Report

Once the workflow completes (~10–20 minutes depending on log volume):

1. Click the completed workflow run
2. Scroll to **Artifacts** section at the bottom
3. Download **`apex-analysis-report`**
4. Open the `.md` file — it contains the full AI analysis per log

---

## Workflow Architecture

```
workflow_dispatch (manual trigger)
        │
        ▼
┌─────────────────────────────┐
│  JOB 1: collect-logs        │
│  ─────────────────────────  │
│  • Install SF CLI           │
│  • Auth via SFDX URL secret │
│  • SOQL query ApexLog obj   │
│  • Download each log body   │
│  • Upload as artifact       │
└─────────────┬───────────────┘
              │ (passes log_count)
              ▼
┌─────────────────────────────┐
│  JOB 2: analyze-logs        │
│  ─────────────────────────  │
│  • Install Ollama locally   │
│  • Pull chosen model        │
│  • Loop through each log    │
│  • POST to local Ollama API │
│  • Append to markdown report│
│  • Upload report artifact   │
└─────────────────────────────┘
```

---

## Choosing Your Model

| Model | Size | Speed | Best For |
|-------|------|-------|----------|
| `mistral` | ~4GB | Fast | General analysis, good Apex understanding |
| `mistral:instruct` | ~4GB | Fast | More structured output format |
| `codellama` | ~4GB | Medium | Code-heavy analysis, better pattern detection |
| `llama3` | ~5GB | Slower | Most thorough, best reasoning |

> 💡 Start with `mistral` — it's the fastest and works well for Salesforce logs.

---

## Troubleshooting

### "No logs found"
- Check trace flags are active in the org (Step 4)
- Increase `days_back` value
- Verify the auth URL secret is correct by checking the org display step

### "Authentication failed"
- Regenerate the SFDX auth URL — sandbox refresh invalidates old URLs
- Re-add the secret: `EXTREMITY_SANDBOX_AUTH_URL`

### "Ollama model pull timeout"
- Reduce `max_logs` to give more time for model pull
- Switch to `mistral` (smallest/fastest model)

### "Analysis is too vague"
- Switch model to `codellama` or `llama3`
- Set `log_level_filter` to `ERROR` to focus on problems
- Reduce `max_logs` so the model gets more time per log

---

## Security Notes

- ✅ All AI inference runs **locally on the GitHub runner** — logs never sent externally
- ✅ Auth URL stored as **encrypted GitHub secret** — never in code
- ✅ Auth URL file is **deleted immediately** after org authentication
- ✅ Artifacts are retained for **30 days** then auto-deleted
- ⚠️ Use a **private repository** — artifacts are visible to repo collaborators

---

## File Placement Summary

```
.github/
└── workflows/
    ├── LogsAnalyzer.yml            ← Manual analysis (any org)
    └── DailyProdHealthReport.yml   ← Scheduled daily report (Production)

scripts/
└── SetTraceFlag.sh                 ← Helper to enable trace flags

files/
└── SETUP_GUIDE.md                  ← This guide
```

---

# 📅 Daily Production Health Report

## Overview

Automatically runs **every morning at 8 AM UTC** and generates a health report for the last 2 days of production logs. The report is:
- Posted as a **GitHub Issue** (with priority labels if critical)
- Sent to **Slack** (optional)
- Available as a downloadable **artifact**

---

## Setup for Daily Reports

### 1. Add Production Auth URL Secret

```bash
# Generate auth URL for your production org
sf org display --target-org YOUR_PROD_ORG --verbose --json | grep sfdxAuthUrl
```

Add to GitHub Secrets:
- Name: `PROD_ORG_AUTH_URL`
- Value: The `force://...` string

### 2. (Optional) Add Slack Webhook

To get Slack notifications:

1. Go to [Slack API](https://api.slack.com/apps) → Create New App
2. Add **Incoming Webhooks** feature
3. Create a webhook for your channel
4. Add to GitHub Secrets:
   - Name: `SLACK_WEBHOOK_URL`
   - Value: `https://hooks.slack.com/services/...`

### 3. Adjust Schedule (Optional)

Edit `.github/workflows/DailyProdHealthReport.yml`:

```yaml
schedule:
  - cron: '0 8 * * *'  # 8 AM UTC daily
```

Common schedules:
| Schedule | Cron |
|----------|------|
| 8 AM UTC Mon-Fri | `0 8 * * 1-5` |
| 6 AM PST daily | `0 14 * * *` |
| 9 AM EST daily | `0 14 * * *` |

---

## What You Get

### GitHub Issue (Auto-Created)
```
🟢 HEALTHY Daily Production Health Report - 2026-03-15

| Metric | Value |
|--------|-------|
| Health Score | 🟢 HEALTHY |
| Logs Analyzed | 24 |
| Errors Detected | 3 |
```

### Slack Message
A color-coded card with health status and link to full report.

### Health Scores
| Score | Meaning |
|-------|---------|
| 🟢 HEALTHY | < 10 errors, no critical issues |
| 🟡 MEDIUM | 10-50 errors |
| 🟠 HIGH RISK | > 50 errors |
| 🔴 CRITICAL | Governor limit exceptions detected |

---

## Manual Trigger

You can also run it manually anytime:
1. Go to **Actions** → **Daily Production Health Report**
2. Click **Run workflow**
3. Set days_back, issue creation, and Slack notification options
