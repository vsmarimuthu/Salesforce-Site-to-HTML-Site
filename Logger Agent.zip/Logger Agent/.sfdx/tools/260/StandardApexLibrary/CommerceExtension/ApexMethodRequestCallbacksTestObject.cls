global class ApexMethodRequestCallbacksTestObject {

}