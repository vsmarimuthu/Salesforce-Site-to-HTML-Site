global class ExtensionInit {

}