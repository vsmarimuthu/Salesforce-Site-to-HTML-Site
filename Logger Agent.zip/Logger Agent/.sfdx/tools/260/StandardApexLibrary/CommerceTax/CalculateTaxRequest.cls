global class CalculateTaxRequest {
	global Boolean isCommit;
	global Boolean isHeaderTaxRequested;
	global Boolean shouldVoidTax;
	global commercetax.TaxTransactionType taxTransactionType;
	global commercetax.CalculateTaxType taxType;
	global CalculateTaxRequest(commercetax.CalculateTaxType taxType) { }
	global Object clone() { }
	global Boolean equals(Object obj) { }
	global Integer hashCode() { }
	global String toString() { }

}