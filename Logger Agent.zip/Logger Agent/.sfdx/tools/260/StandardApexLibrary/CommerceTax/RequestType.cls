global enum RequestType {
CALCULATETAX
}