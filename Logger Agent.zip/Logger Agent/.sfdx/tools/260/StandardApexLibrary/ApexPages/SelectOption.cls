global class SelectOption {

}