global class HammerProcessor {

}