global enum TaxPreferenceEnum {
SKIP
}