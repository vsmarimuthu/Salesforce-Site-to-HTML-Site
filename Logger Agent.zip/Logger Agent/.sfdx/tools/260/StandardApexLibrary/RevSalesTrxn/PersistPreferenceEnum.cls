global enum PersistPreferenceEnum {
SKIP
}